import '#template/js/checkout'
import './custom-js/checkout'

window.ecomPaymentApps = [1250, 111223, 101827, 1251]
window.ecomShippingApps = [101827, 1251, 111223]
